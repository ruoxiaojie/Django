from django.apps import AppConfig


class HostAppConfig(AppConfig):
    name = 'host_app'
