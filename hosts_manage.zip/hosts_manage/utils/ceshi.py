#!/usr/bin/python
#Author:xiaojie
# -*- coding:utf-8 -*-


p="192.168.1."
for i in range(1,10):
    p1=p+str(i)
    print(p1)
    print(type(p1))
